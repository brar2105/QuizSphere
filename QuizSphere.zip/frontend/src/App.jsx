import { useState } from "react";
import { BrowserRouter, Routes, Route, Link, useNavigate } from "react-router-dom";
import "./App.css";

const API = "http://localhost:8080";

function Navbar() {
  return (
    <nav className="navbar">
      <Link className="logo" to="/">
        Quiz<span>Sphere</span>
      </Link>

      <div className="nav-links">
        <Link to="/">Home</Link>
        <Link to="/quizzes">Quizzes</Link>
        <Link to="/login">Login</Link>
        <Link className="nav-btn" to="/register">Get Started</Link>
      </div>
    </nav>
  );
}

function Home() {
  return (
    <>
      <section className="hero">
        <div className="hero-text">
          <div className="badge">✨ Learn • Challenge • Grow</div>
          <h1>Test your knowledge.<br /><span>Master your skills.</span></h1>
          <p>
            Challenge yourself with interactive quizzes, track your progress,
            and become better every day with QuizSphere.
          </p>

          <div className="hero-buttons">
            <Link className="primary-btn" to="/register">Start Quiz Free →</Link>
            <Link className="secondary-btn" to="/quizzes">Explore Quizzes</Link>
          </div>

          <div className="stats">
            <div><strong>100+</strong><small>Questions</small></div>
            <div><strong>20+</strong><small>Quizzes</small></div>
            <div><strong>5K+</strong><small>Students</small></div>
          </div>
        </div>

        <div className="quiz-card">
          <div className="card-top">
            <span>🔥 Popular Quiz</span>
            <span>10 Questions</span>
          </div>
          <h3>Java & Programming</h3>
          <p>Test your programming fundamentals</p>

          <div className="question-progress">
            <div className="progress-fill"></div>
          </div>

          <div className="mini-question">
            <small>QUESTION 03 / 10</small>
            <h4>Which keyword is used to inherit a class in Java?</h4>
            <div className="option">A. implements</div>
            <div className="option selected">B. extends ✓</div>
            <div className="option">C. inherits</div>
            <div className="option">D. super</div>
          </div>
        </div>
      </section>

      <section className="features">
        <div className="section-heading">
          <p>WHY QUIZSPHERE?</p>
          <h2>Everything you need to learn smarter</h2>
        </div>

        <div className="feature-grid">
          <div className="feature-card">
            <div className="feature-icon">🎯</div>
            <h3>Interactive Quizzes</h3>
            <p>Practice with carefully designed questions and instant feedback.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">⚡</div>
            <h3>Instant Results</h3>
            <p>Get your score immediately after completing a quiz.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">📊</div>
            <h3>Track Progress</h3>
            <p>Monitor your performance and improve your weak areas.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">🏆</div>
            <h3>Challenge Yourself</h3>
            <p>Take on new challenges and push your knowledge further.</p>
          </div>
        </div>
      </section>
    </>
  );
}

function Register() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: ""
  });
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const register = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`${API}/api/users`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          role: "STUDENT"
        })
      });

      if (!response.ok) throw new Error();

      setMessage("Account created successfully!");
      setTimeout(() => navigate("/login"), 1000);
    } catch {
      setMessage("Registration failed. Email may already exist.");
    }
  };

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={register}>
        <div className="auth-logo">Quiz<span>Sphere</span></div>
        <h2>Create your account</h2>
        <p>Join QuizSphere and start learning today.</p>

        <label>Full Name</label>
        <input
          required
          placeholder="Enter your name"
          value={form.name}
          onChange={(e) => setForm({...form, name: e.target.value})}
        />

        <label>Email</label>
        <input
          required
          type="email"
          placeholder="you@example.com"
          value={form.email}
          onChange={(e) => setForm({...form, email: e.target.value})}
        />

        <label>Password</label>
        <input
          required
          type="password"
          placeholder="Create a password"
          value={form.password}
          onChange={(e) => setForm({...form, password: e.target.value})}
        />

        <button className="primary-btn full">Create Account</button>

        {message && <div className="message">{message}</div>}

        <p className="auth-bottom">
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </form>
    </div>
  );
}

function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const login = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`${API}/api/users/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      if (!response.ok) throw new Error();

      const user = await response.json();
      localStorage.setItem("user", JSON.stringify(user));

      navigate("/dashboard");
    } catch {
      setMessage("Invalid email or password.");
    }
  };

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={login}>
        <div className="auth-logo">Quiz<span>Sphere</span></div>
        <h2>Welcome back</h2>
        <p>Login to continue your quiz journey.</p>

        <label>Email</label>
        <input
          required
          type="email"
          placeholder="you@example.com"
          value={form.email}
          onChange={(e) => setForm({...form, email: e.target.value})}
        />

        <label>Password</label>
        <input
          required
          type="password"
          placeholder="Enter your password"
          value={form.password}
          onChange={(e) => setForm({...form, password: e.target.value})}
        />

        <button className="primary-btn full">Login</button>

        {message && <div className="error-message">{message}</div>}

        <p className="auth-bottom">
          Don't have an account? <Link to="/register">Register</Link>
        </p>
      </form>
    </div>
  );
}

function Dashboard() {
  const user = JSON.parse(localStorage.getItem("user") || "null");

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <p className="eyebrow">STUDENT DASHBOARD</p>
          <h1>Welcome back, {user?.name || "Student"} 👋</h1>
          <p>Ready to test your knowledge?</p>
        </div>
        <Link className="primary-btn" to="/quizzes">Take a Quiz →</Link>
      </div>

      <div className="dashboard-stats">
        <div><span>📝</span><strong>0</strong><small>Quizzes Taken</small></div>
        <div><span>🏆</span><strong>0%</strong><small>Average Score</small></div>
        <div><span>⭐</span><strong>0</strong><small>Best Score</small></div>
      </div>

      <div className="dashboard-card">
        <h2>Your Learning Journey</h2>
        <p>Start your first quiz to see your progress here.</p>
        <Link className="primary-btn" to="/quizzes">Browse Quizzes</Link>
      </div>
    </div>
  );
}

function Quizzes() {
  const quizzes = [
    { title: "Java Fundamentals", icon: "☕", level: "Beginner", questions: 10 },
    { title: "Data Structures", icon: "🧩", level: "Intermediate", questions: 15 },
    { title: "Database & SQL", icon: "🗄️", level: "Intermediate", questions: 10 },
    { title: "Web Development", icon: "🌐", level: "Beginner", questions: 12 }
  ];

  return (
    <div className="quiz-page">
      <div className="section-heading">
        <p>EXPLORE</p>
        <h1>Choose your challenge</h1>
        <span>Pick a quiz and put your knowledge to the test.</span>
      </div>

      <div className="quiz-grid">
        {quizzes.map((quiz) => (
          <div className="quiz-item" key={quiz.title}>
            <div className="quiz-icon">{quiz.icon}</div>
            <span className="level">{quiz.level}</span>
            <h3>{quiz.title}</h3>
            <p>{quiz.questions} Questions • Multiple Choice</p>
            <Link className="quiz-start" to="/quiz">Start Quiz →</Link>
          </div>
        ))}
      </div>
    </div>
  );
}

function Quiz() {
  const [selected, setSelected] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const options = ["implements", "extends", "inherits", "super"];

  return (
    <div className="quiz-container">
      <div className="quiz-header">
        <div>
          <span>JAVA FUNDAMENTALS</span>
          <h2>Question 3 of 10</h2>
        </div>
        <div className="timer">⏱ 08:42</div>
      </div>

      <div className="big-progress">
        <div></div>
      </div>

      <div className="question-card">
        <p className="question-number">QUESTION 03</p>
        <h1>Which keyword is used to inherit a class in Java?</h1>

        <div className="answers">
          {options.map((option, index) => (
            <button
              key={option}
              className={selected === option ? "answer selected-answer" : "answer"}
              onClick={() => setSelected(option)}
            >
              <span>{String.fromCharCode(65 + index)}</span>
              {option}
            </button>
          ))}
        </div>

        <div className="quiz-actions">
          <button className="secondary-btn">← Previous</button>
          <button
            className="primary-btn"
            onClick={() => setSubmitted(true)}
          >
            {submitted ? "Answer Saved ✓" : "Next Question →"}
          </button>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/quizzes" element={<Quizzes />} />
        <Route path="/quiz" element={<Quiz />} />
      </Routes>

      <footer>
        <strong>QuizSphere</strong>
        <span>Learn. Challenge. Succeed.</span>
      </footer>
    </BrowserRouter>
  );
}

export default App;
