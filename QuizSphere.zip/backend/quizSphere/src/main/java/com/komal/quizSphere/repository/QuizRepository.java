package com.komal.quizSphere.repository;

import com.komal.quizSphere.entity.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuizRepository extends JpaRepository<Quiz, Long> {
}
