const API_URL = import.meta.env.VITE_API_URL;

export async function apiRequest(endpoint, options = {}) {
  const response = await fetch(`${API_URL}${endpoint}`, {
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
    ...options,
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || `Request failed: ${response.status}`);
  }

  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

export const getUsers = () => apiRequest("/api/users");

export const registerUser = (user) =>
  apiRequest("/api/users", {
    method: "POST",
    body: JSON.stringify(user),
  });

export const loginUser = (user) =>
  apiRequest("/api/users/login", {
    method: "POST",
    body: JSON.stringify(user),
  });

export const getQuizzes = () => apiRequest("/api/quizzes");

export const getQuiz = (id) => apiRequest(`/api/quizzes/${id}`);

export const getQuestionsByQuiz = (quizId) =>
  apiRequest(`/api/questions/quiz/${quizId}`);

export const getResultsByUser = (userId) =>
  apiRequest(`/api/results/user/${userId}`);

export const submitResult = (result) =>
  apiRequest("/api/results", {
    method: "POST",
    body: JSON.stringify(result),
  });